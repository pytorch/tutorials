"""
Zeroing out gradients in PyTorch
================================
It is beneficial to zero out gradients when building a neural network.
This is because by default, gradients are accumulated in buffers (i.e,
not overwritten) whenever ``.backward()`` is called.

Introduction
------------
When training your neural network, models are able to increase their
accuracy through gradient descent. In short, gradient descent is the
process of minimizing our loss (or error) by tweaking the weights and
biases in our model.

``torch.Tensor`` is the central class of PyTorch. When you create a
tensor, if you set its attribute ``.requires_grad`` as ``True``, the
package tracks all operations on it. This happens on subsequent backward
passes. The gradient for this tensor will be accumulated into ``.grad``
attribute. The accumulation (or sum) of all the gradients is calculated
when .backward() is called on the loss tensor.

There are cases where it may be necessary to zero-out the gradients of a
tensor. For example: when you start your training loop, you should zero
out the gradients so that you can perform this tracking correctly.
In this recipe, we will learn how to zero out gradients using the
PyTorch library. We will demonstrate how to do this by training a neural
network on the ``CIFAR10`` dataset built into PyTorch.

Setup
-----
Since we will be training data in this recipe, if you are in a runnable
notebook, it is best to switch the runtime to GPU or TPU.
Before we begin, we need to install ``torch`` and ``torchvision`` if
they aren’t already available.

.. code-block:: sh

   pip install torchvision


"""


######################################################################
# Steps
# -----
#
# Steps 1 through 4 set up our data and neural network for training. The
# process of zeroing out the gradients happens in step 5. If you already
# have your data and neural network built, skip to 5.
#
# 1. Import all necessary libraries for loading our data
# 2. Load and normalize the dataset
# 3. Build the neural network
# 4. Define the loss function
# 5. Zero the gradients while training the network
#
# 1. Import necessary libraries for loading our data
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# For this recipe, we will just be using ``torch`` and ``torchvision`` to
# access the dataset.
#












######################################################################
# 2. Load and normalize the dataset
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# PyTorch features various built-in datasets (see the Loading Data recipe
# for more information).
#



















######################################################################
# 3. Build the neural network
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# We will use a convolutional neural network. To learn more see the
# Defining a Neural Network recipe.
#





















######################################################################
# 4. Define a Loss function and optimizer
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# Let’s use a Classification Cross-Entropy loss and SGD with momentum.
#






######################################################################
# 5. Zero the gradients while training the network
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# This is when things start to get interesting. We simply have to loop
# over our data iterator, and feed the inputs to the network and optimize.
#
# Notice that for each entity of data, we zero out the gradients. This is
# to ensure that we aren’t tracking any unnecessary information when we
# train our neural network.
#



























######################################################################
# You can also use ``model.zero_grad()``. This is the same as using
# ``optimizer.zero_grad()`` as long as all your model parameters are in
# that optimizer. Use your best judgment to decide which one to use.
#
# Congratulations! You have successfully zeroed out gradients in PyTorch.
#
# Learn More
# ----------
#
# Take a look at these other recipes to continue your learning:
#
# - `Loading data in PyTorch <https://pytorch.org/tutorials/beginner/basics/data_tutorial.html>`__
# - `Saving and loading models across devices in PyTorch <https://pytorch.org/tutorials/recipes/recipes/save_load_across_devices.html>`__

# %%%%%%RUNNABLE_CODE_REMOVED%%%%%%