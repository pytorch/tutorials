# -*- coding: utf-8 -*-
"""
Warm-up: numpy
--------------

A third order polynomial, trained to predict :math:`y=\sin(x)` from :math:`-\pi`
to :math:`\pi` by minimizing squared Euclidean distance.

This implementation uses numpy to manually compute the forward pass, loss, and
backward pass.

A numpy array is a generic n-dimensional array; it does not know anything about
deep learning or gradients or computational graphs, and is just a way to perform
generic numeric computations.
"""



# Create random input and output data



# Randomly initialize weights































# %%%%%%RUNNABLE_CODE_REMOVED%%%%%%