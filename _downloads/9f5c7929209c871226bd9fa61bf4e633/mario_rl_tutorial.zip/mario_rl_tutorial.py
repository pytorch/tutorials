# -*- coding: utf-8 -*-
"""
Train a Mario-playing RL Agent
===============================

**Authors:** `Yuansong Feng <https://github.com/YuansongFeng>`__, `Suraj Subramanian <https://github.com/suraj813>`__, `Howard Wang <https://github.com/hw26>`__, `Steven Guo <https://github.com/GuoYuzhang>`__.


This tutorial walks you through the fundamentals of Deep Reinforcement
Learning. At the end, you will implement an AI-powered Mario (using
`Double Deep Q-Networks <https://arxiv.org/pdf/1509.06461.pdf>`__) that
can play the game by itself.

Although no prior knowledge of RL is necessary for this tutorial, you
can familiarize yourself with these RL
`concepts <https://spinningup.openai.com/en/latest/spinningup/rl_intro.html>`__,
and have this handy
`cheatsheet <https://colab.research.google.com/drive/1eN33dPVtdPViiS1njTW_-r-IYCDTFU7N>`__
as your companion. The full code is available
`here <https://github.com/yuansongFeng/MadMario/>`__.

.. figure:: /_static/img/mario.gif
   :alt: mario

"""


######################################################################
#
#
#  .. code-block:: bash
#
#      %%bash
#      pip install gym-super-mario-bros==7.4.0
#      pip install tensordict==0.3.0
#      pip install torchrl==0.3.0
#










# Gym is an OpenAI toolkit for RL




# NES Emulator for OpenAI Gym


# Super Mario environment for OpenAI Gym





######################################################################
# RL Definitions
# """"""""""""""""""
#
# **Environment** The world that an agent interacts with and learns from.
#
# **Action** :math:`a` : How the Agent responds to the Environment. The
# set of all possible Actions is called *action-space*.
#
# **State** :math:`s` : The current characteristic of the Environment. The
# set of all possible States the Environment can be in is called
# *state-space*.
#
# **Reward** :math:`r` : Reward is the key feedback from Environment to
# Agent. It is what drives the Agent to learn and to change its future
# action. An aggregation of rewards over multiple time steps is called
# **Return**.
#
# **Optimal Action-Value function** :math:`Q^*(s,a)` : Gives the expected
# return if you start in state :math:`s`, take an arbitrary action
# :math:`a`, and then for each future time step take the action that
# maximizes returns. :math:`Q` can be said to stand for the “quality” of
# the action in a state. We try to approximate this function.
#


######################################################################
# Environment
# """"""""""""""""
#
# Initialize Environment
# ------------------------
#
# In Mario, the environment consists of tubes, mushrooms and other
# components.
#
# When Mario makes an action, the environment responds with the changed
# (next) state, reward and other info.
#

# Initialize Super Mario environment (in v0.26 change render mode to 'human' to see results on the screen)





# Limit the action-space to
#   0. walk right
#   1. jump right







######################################################################
# Preprocess Environment
# ------------------------
#
# Environment data is returned to the agent in ``next_state``. As you saw
# above, each state is represented by a ``[3, 240, 256]`` size array.
# Often that is more information than our agent needs; for instance,
# Mario’s actions do not depend on the color of the pipes or the sky!
#
# We use **Wrappers** to preprocess environment data before sending it to
# the agent.
#
# ``GrayScaleObservation`` is a common wrapper to transform an RGB image
# to grayscale; doing so reduces the size of the state representation
# without losing useful information. Now the size of each state:
# ``[1, 240, 256]``
#
# ``ResizeObservation`` downsamples each observation into a square image.
# New size: ``[1, 84, 84]``
#
# ``SkipFrame`` is a custom wrapper that inherits from ``gym.Wrapper`` and
# implements the ``step()`` function. Because consecutive frames don’t
# vary much, we can skip n-intermediate frames without losing much
# information. The n-th frame aggregates rewards accumulated over each
# skipped frame.
#
# ``FrameStack`` is a wrapper that allows us to squash consecutive frames
# of the environment into a single observation point to feed to our
# learning model. This way, we can identify if Mario was landing or
# jumping based on the direction of his movement in the previous several
# frames.
#


























































# Apply Wrappers to environment









######################################################################
# After applying the above wrappers to the environment, the final wrapped
# state consists of 4 gray-scaled consecutive frames stacked together, as
# shown above in the image on the left. Each time Mario makes an action,
# the environment responds with a state of this structure. The structure
# is represented by a 3-D array of size ``[4, 84, 84]``.
#
# .. figure:: /_static/img/mario_env.png
#    :alt: picture
#
#


######################################################################
# Agent
# """""""""
#
# We create a class ``Mario`` to represent our agent in the game. Mario
# should be able to:
#
# -  **Act** according to the optimal action policy based on the current
#    state (of the environment).
#
# -  **Remember** experiences. Experience = (current state, current
#    action, reward, next state). Mario *caches* and later *recalls* his
#    experiences to update his action policy.
#
# -  **Learn** a better action policy over time
#























######################################################################
# In the following sections, we will populate Mario’s parameters and
# define his functions.
#


######################################################################
# Act
# --------------
#
# For any given state, an agent can choose to do the most optimal action
# (**exploit**) or a random action (**explore**).
#
# Mario randomly explores with a chance of ``self.exploration_rate``; when
# he chooses to exploit, he relies on ``MarioNet`` (implemented in
# ``Learn`` section) to provide the most optimal action.
#


















































######################################################################
# Cache and Recall
# ----------------------
#
# These two functions serve as Mario’s “memory” process.
#
# ``cache()``: Each time Mario performs an action, he stores the
# ``experience`` to his memory. His experience includes the current
# *state*, *action* performed, *reward* from the action, the *next state*,
# and whether the game is *done*.
#
# ``recall()``: Mario randomly samples a batch of experiences from his
# memory, and uses that to learn the game.
#










































######################################################################
# Learn
# --------------
#
# Mario uses the `DDQN algorithm <https://arxiv.org/pdf/1509.06461>`__
# under the hood. DDQN uses two ConvNets - :math:`Q_{online}` and
# :math:`Q_{target}` - that independently approximate the optimal
# action-value function.
#
# In our implementation, we share feature generator ``features`` across
# :math:`Q_{online}` and :math:`Q_{target}`, but maintain separate FC
# classifiers for each. :math:`\theta_{target}` (the parameters of
# :math:`Q_{target}`) is frozen to prevent updating by backprop. Instead,
# it is periodically synced with :math:`\theta_{online}` (more on this
# later).
#
# Neural Network
# ~~~~~~~~~~~~~~~~~~














































######################################################################
# TD Estimate & TD Target
# ~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# Two values are involved in learning:
#
# **TD Estimate** - the predicted optimal :math:`Q^*` for a given state
# :math:`s`
#
# .. math::
#
#
#    {TD}_e = Q_{online}^*(s,a)
#
# **TD Target** - aggregation of current reward and the estimated
# :math:`Q^*` in the next state :math:`s'`
#
# .. math::
#
#
#    a' = argmax_{a} Q_{online}(s', a)
#
# .. math::
#
#
#    {TD}_t = r + \gamma Q_{target}^*(s',a')
#
# Because we don’t know what next action :math:`a'` will be, we use the
# action :math:`a'` maximizes :math:`Q_{online}` in the next state
# :math:`s'`.
#
# Notice we use the
# `@torch.no_grad() <https://pytorch.org/docs/stable/generated/torch.no_grad.html#no-grad>`__
# decorator on ``td_target()`` to disable gradient calculations here
# (because we don’t need to backpropagate on :math:`\theta_{target}`).
#























######################################################################
# Updating the model
# ~~~~~~~~~~~~~~~~~~~~~~
#
# As Mario samples inputs from his replay buffer, we compute :math:`TD_t`
# and :math:`TD_e` and backpropagate this loss down :math:`Q_{online}` to
# update its parameters :math:`\theta_{online}` (:math:`\alpha` is the
# learning rate ``lr`` passed to the ``optimizer``)
#
# .. math::
#
#
#    \theta_{online} \leftarrow \theta_{online} + \alpha \nabla(TD_e - TD_t)
#
# :math:`\theta_{target}` does not update through backpropagation.
# Instead, we periodically copy :math:`\theta_{online}` to
# :math:`\theta_{target}`
#
# .. math::
#
#
#    \theta_{target} \leftarrow \theta_{online}
#
#



















######################################################################
# Save checkpoint
# ~~~~~~~~~~~~~~~~~~
#














######################################################################
# Putting it all together
# ~~~~~~~~~~~~~~~~~~~~~~~~~~
#





































######################################################################
# Logging
# --------------
#













































































































######################################################################
# Let’s play!
# """""""""""""""
#
# In this example we run the training loop for 40 episodes, but for Mario to truly learn the ways of
# his world, we suggest running the loop for at least 40,000 episodes!
#















































######################################################################
# Conclusion
# """""""""""""""
#
# In this tutorial, we saw how we can use PyTorch to train a game-playing AI. You can use the same methods
# to train an AI to play any of the games at the `OpenAI gym <https://gym.openai.com/>`__. Hope you enjoyed this tutorial, feel free to reach us at
# `our github <https://github.com/yuansongFeng/MadMario/>`__!

# %%%%%%RUNNABLE_CODE_REMOVED%%%%%%