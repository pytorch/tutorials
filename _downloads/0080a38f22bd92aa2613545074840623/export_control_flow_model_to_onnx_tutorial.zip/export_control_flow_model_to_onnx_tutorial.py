# -*- coding: utf-8 -*-
"""
`Introduction to ONNX <intro_onnx.html>`_ ||
`Exporting a PyTorch model to ONNX <export_simple_model_to_onnx_tutorial.html>`_ ||
`Extending the ONNX exporter operator support <onnx_registry_tutorial.html>`_ ||
**`Export a model with control flow to ONNX**

Export a model with control flow to ONNX
========================================

**Author**: `Xavier Dupré <https://github.com/xadupre>`_
"""


###############################################################################
# Overview
# --------
# 
# This tutorial demonstrates how to handle control flow logic while exporting
# a PyTorch model to ONNX. It highlights the challenges of exporting
# conditional statements directly and provides solutions to circumvent them.
#
# Conditional logic cannot be exported into ONNX unless they refactored
# to use :func:`torch.cond`. Let's start with a simple model
# implementing a test.
# 
# What you will learn:
#
# - How to refactor the model to use :func:`torch.cond` for exporting.
# - How to export a model with control flow logic to ONNX.
# - How to optimize the exported model using the ONNX optimizer.
#
# Prerequisites
# ~~~~~~~~~~~~~
#
# * ``torch >= 2.6``




###############################################################################
# Define the Models
# -----------------
#
# Two models are defined:
#
# ``ForwardWithControlFlowTest``: A model with a forward method containing an
# if-else conditional.
#
# ``ModelWithControlFlowTest``: A model that incorporates ``ForwardWithControlFlowTest``
# as part of a simple MLP. The models are tested with
# a random input tensor to confirm they execute as expected.

























###############################################################################
# Exporting the Model: First Attempt
# ----------------------------------
#
# Exporting this model using torch.export.export fails because the control
# flow logic in the forward pass creates a graph break that the exporter cannot
# handle. This behavior is expected, as conditional logic not written using
# :func:`torch.cond` is unsupported.
# 
# A try-except block is used to capture the expected failure during the export
# process. If the export unexpectedly succeeds, an ``AssertionError`` is raised.










###############################################################################
# Using :func:`torch.onnx.export` with JIT Tracing
# ----------------------------------------
#
# When exporting the model using :func:`torch.onnx.export` with the dynamo=True
# argument, the exporter defaults to using JIT tracing. This fallback allows
# the model to export, but the resulting ONNX graph may not faithfully represent
# the original model logic due to the limitations of tracing.






###############################################################################
# Suggested Patch: Refactoring with :func:`torch.cond`
# --------------------------------------------
#
# To make the control flow exportable, the tutorial demonstrates replacing the
# forward method in ``ForwardWithControlFlowTest`` with a refactored version that
# uses :func:`torch.cond``.
#
# Details of the Refactoring:
#
# Two helper functions (identity2 and neg) represent the branches of the conditional logic:
# * :func:`torch.cond`` is used to specify the condition and the two branches along with the input arguments.
# * The updated forward method is then dynamically assigned to the ``ForwardWithControlFlowTest`` instance within the model. A list of submodules is printed to confirm the replacement.

















###############################################################################
# Let's see what the FX graph looks like.



###############################################################################
# Let's export again.





###############################################################################
# We can optimize the model and get rid of the model local functions created to capture the control flow branches.  




###############################################################################
# Conclusion
# ----------
#
# This tutorial demonstrates the challenges of exporting models with conditional
# logic to ONNX and presents a practical solution using :func:`torch.cond`.
# While the default exporters may fail or produce imperfect graphs, refactoring the
# model's logic ensures compatibility and generates a faithful ONNX representation.
#
# By understanding these techniques, we can overcome common pitfalls when
# working with control flow in PyTorch models and ensure smooth integration with ONNX workflows.
#
# Further reading
# ---------------
#
# The list below refers to tutorials that ranges from basic examples to advanced scenarios,
# not necessarily in the order they are listed.
# Feel free to jump directly to specific topics of your interest or
# sit tight and have fun going through all of them to learn all there is about the ONNX exporter.
#
# .. include:: /beginner_source/onnx/onnx_toc.txt
#
# .. toctree::
#    :hidden:
#
# %%%%%%RUNNABLE_CODE_REMOVED%%%%%%