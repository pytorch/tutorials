"""
Using Variable Length Attention in PyTorch
==========================================

.. meta::
   :description: Learn how to use PyTorch's varlen_attn API for efficient variable length attention without padding. Complete tutorial with code examples for training Transformers with packed sequences.
   :keywords: pytorch, attention, variable length, transformer, varlen_attn, packed sequences, memory optimization, torch.compile

**Author:** `Angel Li <https://github.com/liangel-02>`_


In this tutorial, we will introduce a variable length attention API.
This API is called ``varlen_attn`` and is a custom op in PyTorch,
meaning it is also compilable using ``torch.compile``.

"""

######################################################################
#    | **Note:**
#    | This tutorial currently requires you to use the PyTorch nightly
#      build. This op currently only works with NVIDIA CUDA on A100 machines
#      or newer. Supported dtypes include BF16 and FP16.
#
# What you will learn
# ~~~~~~~~~~~~~~~~~~~
#
# -  Variable length attention and how it differs from
#    Scaled Dot Product Attention (SDPA)
# -  Explore an example of how to use ``varlen_attn`` in a simple
#    Transformer attention layer
#
# Prerequisites
# ~~~~~~~~~~~~~
#
# -  PyTorch v2.10.0.dev or later
# -  NVIDIA A100 GPU or newer
# -  A basic understanding of attention and our current offerings. Please
#    reference these tutorials for more details on `FlexAttention <https://pytorch.org/blog/flexattention/>`__ and
#    `SDPA <https://docs.pytorch.org/tutorials/intermediate/scaled_dot_product_attention_tutorial.html>`__.
#


######################################################################
# Overview of Variable Length Attention
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# In normal SDPA, sequences are expected to be a fixed length. In
# practice, this means that input tensors are often **padded** to the same
# length in a batch. However, this wastes both memory and compute through
# storing this padding and performing unnecessary computations.
# Variable length attention handles sequences of varying length by
# **packing** the tensors in a batch together and essentially collapsing
# the batch dimension.


######################################################################
# However, we still need to maintain the boundaries between documents. To
# do so, we compute cumulative sequence positions for query and key/value
# that mark the end of documents. In the diagram below, doc 1 is 7 tokens
# long, doc 2 is 10 tokens long, etc. so ``cu_seq_lens = [0, 7, 17, ...]``.
#
# .. figure:: ../_static/img/varlen_diagram.png
#    :alt: Diagram comparing two approaches for handling variable-length
#       sequences in attention. Left side labeled 'PADDING (SDPA)' shows a 2D
#       batch of 4 samples stacked vertically, each padded to match the longest
#       sequence (length 10). Sample 1 has length 7 with 3 padding tokens,
#       sample 2 has length 10 with no padding, sample 3 has length 8 with 2
#       padding tokens, and sample 4 has length 5 with 5 padding tokens. The
#       vertical axis represents batch size and horizontal axis represents
#       sequence length. Right side labeled 'PACKING (VARLEN)' shows the same 4
#       samples concatenated into a single 1D sequence with no padding. Arrows
#       indicate boundaries at positions 7, 17, 25, and 30. Below shows
#       cu_seq_lens: [0, 7, 17, 25, 30] representing cumulative sequence
#       lengths, and max_seqlen: 10.
#
#    Padding vs Packing Diagram


######################################################################
# Note that ``NestedTensor`` is another way to enable
# variable length with packed tensors (see tutorial
# `here <https://docs.pytorch.org/tutorials/unstable/nestedtensor.html>`__).


######################################################################
# Definition
# ----------
#
# Below is the definition of ``varlen_attn`` which returns the output
# tensor from the attention computation.
#
# .. code:: python
#
#    def varlen_attn(
#        query: torch.Tensor,
#        key: torch.Tensor,
#        value: torch.Tensor,
#        cu_seq_q: torch.Tensor,
#        cu_seq_k: torch.Tensor,
#        max_q: int,
#        max_k: int,
#        is_causal: bool = False,
#        return_aux: AuxRequest | None = None,
#    ) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor]:
#
# ``query``, ``key``, and ``value`` correspond to the ``q``, ``k``, and
# ``v`` of the packed input. ``cu_seq_q`` and ``cu_seq_k`` are the
# cumulative indices for query and key/value, respectively. These mark the
# logical boundaries that separate the documents in our input. ``max_q``
# and ``max_k`` are the maximum sequence lengths of query and key,
# respectively. ``is_causal`` applies causal masking if set to True and
# ``return_aux`` specifies which auxiliary outputs to return (ie ``lse``).

######################################################################
# **Note on causal masking**
# When ``is_causal`` is set to True, causal masking is applied which means
# that tokens can only attend to previous tokens. For bidirectional
# attention, set this flag to False.
#
# In torchtitan (PyTorch's pretraining framework), we set
# ``is_causal = True`` uniformly to prevent the model from cheating and
# artificially driving the loss down too quickly.


######################################################################
# Example
# ~~~~~~~
#
# Let’s walk through a simple example of how we would use ``varlen_attn``
# in the context of training a Transformer model.
#


######################################################################
# Creating Required Metadata for ``varlen_attn`` from Input Batches
# -----------------------------------------------------------------
#
# Given an input batch, how would we construct the metadata that
# ``varlen_attn`` expects? More specifically, how do we calculate the
# cumulative sequence indices?
#
# The helper function ``create_varlen_metadata`` returns the required
# ``cu_seqlens`` and ``max_seqlen`` given ``input_batch`` and the end of
# sequence token ID that marks the end of documents.
#












































######################################################################
# Implementing the Attention Block with ``varlen_attn``
# -----------------------------------------------------
#
# Let's explore how we would use ``varlen_attn`` in an Attention module.
# We define an attention module as usual, but in the ``forward`` method,
# we call the new ``varlen_attn`` custom op.
#
# This function expects the ``cu_seq`` indices and ``max_len`` that we
# computed earlier using ``create_varlen_metadata`` to mark the boundaries
# of the different documents.
#
# Before we call ``varlen_attn``, we also pack our input so that it has
# the shape ``(total tokens, dim)``. Recall that variable length attention
# allows us to collapse the ``batch_size`` dimension so that we can lay
# out our input samples contiguously.
#












































######################################################################
# We can also use ``torch.compile`` with ``varlen_attn`` and define:
#
# .. code:: python
#
#    compiled_varlen_attn: ClassVar[Callable] = torch.compile(
#        varlen_attn, mode="max-autotune-no-cudagraphs"
#    )
#
# We can call ``compiled_varlen_attn`` instead of ``varlen_attn`` in the
# Attention forward, and everything else stays the same.


######################################################################
# Creating a Transformer
# ----------------------
#
# Now, we can use this ``SimpleVarlenAttention`` module in a simple
# Transformer.
#






















######################################################################
# Running a Training Step
# -----------------------
#
# Now we’re ready to put all the pieces together! Let’s run a training
# step with our ``SimpleVarlenTransformer``. We define our model, compute
# ``cu_seq`` and ``max_len`` using ``create_varlen_metadata``, and run a
# forward and backward pass.
#















































######################################################################
# Conclusion
# ~~~~~~~~~~
#
# In this tutorial, we have covered how to use the ``varlen_attn`` API in PyTorch to efficiently
# handle sequences of varying lengths without padding. We explored how to create the
# necessary metadata including the cumulative sequence indices, implemented a simple
# Transformer attention layer with variable length attention, and ran a complete
# training step.

######################################################################
# This approach eliminates wasted computation on padding tokens
# and enables more efficient training and inference for models processing
# documents of different lengths.
#
# .. seealso::
#
#    - `Implementing High-Performance Transformers with Scaled Dot Product Attention <https://docs.pytorch.org/tutorials/intermediate/scaled_dot_product_attention_tutorial.html>`_
#    - `torch.nn.functional.scaled_dot_product_attention <https://docs.pytorch.org/docs/stable/generated/torch.nn.functional.scaled_dot_product_attention.html>`_

# %%%%%%RUNNABLE_CODE_REMOVED%%%%%%