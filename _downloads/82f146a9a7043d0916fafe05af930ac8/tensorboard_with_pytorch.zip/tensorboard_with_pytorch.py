"""
How to use TensorBoard with PyTorch
===================================
TensorBoard is a visualization toolkit for machine learning experimentation. 
TensorBoard allows tracking and visualizing metrics such as loss and accuracy, 
visualizing the model graph, viewing histograms, displaying images and much more. 
In this tutorial we are going to cover TensorBoard installation, 
basic usage with PyTorch, and how to visualize data you logged in TensorBoard UI.

Installation
----------------------
PyTorch should be installed to log models and metrics into the TensorBoard log
directory. Install PyTorch with:

.. code-block:: sh

   pip install torch torchvision

"""

######################################################################
# Using TensorBoard in PyTorch
# -----------------------------
# 
# Let’s now try using TensorBoard with PyTorch! Before logging anything, 
# we need to create a ``SummaryWriter`` instance.
#   





######################################################################
# Writer will output to ``./runs/`` directory by default.
# 


######################################################################
# Log scalars
# -----------
# 
# In machine learning, it’s important to understand key metrics such as 
# loss and how they change during training. Scalar helps to save 
# the loss value of each training step, or the accuracy after each epoch. 
#
# To log a scalar value, use 
# ``add_scalar(tag, scalar_value, global_step=None, walltime=None)``. 
# For example, lets create a simple linear regression training, and 
# log loss value using ``add_scalar``
#





















###################################################################### 
# Call ``flush()`` method to make sure that all pending events 
# have been written to disk.
# 
# See `torch.utils.tensorboard tutorials <https://pytorch.org/docs/stable/tensorboard.html>`_ 
# to find more TensorBoard visualization types you can log.
# 
# If you do not need the summary writer anymore, call ``close()`` method.
#



######################################################################
# Run TensorBoard
# ----------------
# 
# Install TensorBoard through the command line to visualize data you logged
#
# .. code-block:: sh
#
#    pip install tensorboard
#
#
# Now, start TensorBoard, specifying the root log directory you used above. 
# Argument ``logdir`` points to directory where TensorBoard will look to find 
# event files that it can display. TensorBoard will recursively walk 
# the directory structure rooted at ``logdir``, looking for ``.*tfevents.*`` files.
#
# .. code-block:: sh
#
#    tensorboard --logdir=runs
#
# Go to the URL it provides OR to `http://localhost:6006/ <http://localhost:6006/>`_
#
# .. image:: ../../_static/img/thumbnails/tensorboard_scalars.png
#    :scale: 40 %
#
# This dashboard shows how the loss and accuracy change with every epoch. 
# You can use it to also track training speed, learning rate, and other 
# scalar values. It’s helpful to compare these metrics across different 
# training runs to improve your model.
#


########################################################################
# Learn More
# ----------------------------
# 
# -  `torch.utils.tensorboard <https://pytorch.org/docs/stable/tensorboard.html>`_ docs
# -  `Visualizing models, data, and training with TensorBoard <https://pytorch.org/tutorials/intermediate/tensorboard_tutorial.html>`_ tutorial
#

# %%%%%%RUNNABLE_CODE_REMOVED%%%%%%