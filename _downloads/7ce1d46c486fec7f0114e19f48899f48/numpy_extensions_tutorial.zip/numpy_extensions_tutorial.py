# -*- coding: utf-8 -*-
"""
Creating Extensions Using NumPy and SciPy
=========================================
**Author**: `Adam Paszke <https://github.com/apaszke>`_

**Updated by**: `Adam Dziedzic <https://github.com/adam-dziedzic>`_

In this tutorial, we shall go through two tasks:

1. Create a neural network layer with no parameters.

    -  This calls into **numpy** as part of its implementation

2. Create a neural network layer that has learnable weights

    -  This calls into **SciPy** as part of its implementation
"""




###############################################################
# Parameter-less example
# ----------------------
#
# This layer doesn’t particularly do anything useful or mathematically
# correct.
#
# It is aptly named ``BadFFTFunction``
#
# **Layer Implementation**

















# since this layer does not have any parameters, we can
# simply declare this as a function, rather than as an ``nn.Module`` class





###############################################################
# **Example usage of the created layer:**







###############################################################
# Parametrized example
# --------------------
#
# In deep learning literature, this layer is confusingly referred
# to as convolution while the actual operation is cross-correlation
# (the only difference is that filter is flipped for convolution,
# which is not the case for cross-correlation).
#
# Implementation of a layer with learnable weights, where cross-correlation
# has a filter (kernel) that represents weights.
#
# The backward pass computes the gradient ``wrt`` the input and the gradient ``wrt`` the filter.









































###############################################################
# **Example usage:**









###############################################################
# **Check the gradients:**









# %%%%%%RUNNABLE_CODE_REMOVED%%%%%%