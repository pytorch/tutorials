# -*- coding: utf-8 -*-
"""
PyTorch: Tensors
----------------

A third order polynomial, trained to predict :math:`y=\sin(x)` from :math:`-\pi`
to :math:`pi` by minimizing squared Euclidean distance.

This implementation uses PyTorch tensors to manually compute the forward pass,
loss, and backward pass.

A PyTorch Tensor is basically the same as a numpy array: it does not know
anything about deep learning or computational graphs or gradients, and is just
a generic n-dimensional array to be used for arbitrary numeric computation.

The biggest difference between a numpy array and a PyTorch Tensor is that
a PyTorch Tensor can run on either CPU or GPU. To run operations on the GPU,
just cast the Tensor to a cuda datatype.
"""







# device = torch.device("cuda:0") # Uncomment this to run on GPU

# Create random input and output data



# Randomly initialize weights































# %%%%%%RUNNABLE_CODE_REMOVED%%%%%%