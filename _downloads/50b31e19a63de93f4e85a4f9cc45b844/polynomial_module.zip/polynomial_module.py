# -*- coding: utf-8 -*-
"""
PyTorch: Custom nn Modules
--------------------------

A third order polynomial, trained to predict :math:`y=\sin(x)` from :math:`-\pi`
to :math:`\pi` by minimizing squared Euclidean distance.

This implementation defines the model as a custom Module subclass. Whenever you
want a model more complex than a simple sequence of existing Modules you will
need to define your model this way.
"""































# Create Tensors to hold input and outputs.



# Construct our model by instantiating the class defined above


# Construct our loss function and an Optimizer. The call to model.parameters()
# in the SGD constructor will contain the learnable parameters (defined 
# with torch.nn.Parameter) which are members of the model.


















# %%%%%%RUNNABLE_CODE_REMOVED%%%%%%