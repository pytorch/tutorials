# -*- coding: utf-8 -*-
"""
PyTorch: Control Flow + Weight Sharing
--------------------------------------

To showcase the power of PyTorch dynamic graphs, we will implement a very strange
model: a third-fifth order polynomial that on each forward pass
chooses a random number between 4 and 5 and uses that many orders, reusing
the same weights multiple times to compute the fourth and fifth order.
"""









































# Create Tensors to hold input and outputs.



# Construct our model by instantiating the class defined above


# Construct our loss function and an Optimizer. Training this strange model with
# vanilla stochastic gradient descent is tough, so we use momentum


















# %%%%%%RUNNABLE_CODE_REMOVED%%%%%%